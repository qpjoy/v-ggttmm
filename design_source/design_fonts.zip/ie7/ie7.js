/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'GTM_iconfont\'">' + entity + '</span>' + html;
	}
	var icons = {
		'GTM_icon_Add': '&#xe900;',
		'GTM_icon_Arrow-collapse': '&#xe901;',
		'GTM_icon_Arrow-dropdown': '&#xe902;',
		'GTM_icon_Arrow-expend': '&#xe903;',
		'GTM_icon_Arrow-left': '&#xe904;',
		'GTM_icon_Arrow-right': '&#xe905;',
		'GTM_icon_Back': '&#xe906;',
		'GTM_icon_Call': '&#xe907;',
		'GTM_icon_Camera': '&#xe908;',
		'GTM_icon_Checkbox-empty': '&#xe909;',
		'GTM_icon_Checkbox': '&#xe90a;',
		'GTM_icon_Done': '&#xe90b;',
		'GTM_icon_Homepage': '&#xe90c;',
		'GTM_icon_Inventory': '&#xe90d;',
		'GTM_icon_Location': '&#xe90e;',
		'GTM_icon_Minus': '&#xe90f;',
		'GTM_icon_More': '&#xe910;',
		'GTM_icon_Navigate': '&#xe911;',
		'GTM_icon_Orders': '&#xe912;',
		'GTM_icon_Profile': '&#xe913;',
		'GTM_icon_QRCode': '&#xe914;',
		'GTM_icon_Report-issue': '&#xe915;',
		'GTM_icon_Route-done': '&#xe916;',
		'GTM_icon_Route-Nav': '&#xe917;',
		'GTM_icon_Route-Store': '&#xe918;',
		'GTM_icon_Route': '&#xe919;',
		'GTM_icon_Search': '&#xe91a;',
		'GTM_icon_Star': '&#xe91b;',
		'GTM_icon_Store': '&#xe91c;',
		'GTM_icon_Sync': '&#xe91d;',
		'GTM_icon_Voice': '&#xe91e;',
		'GTM_icon_Voiceinput': '&#xe91f;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/GTM_icon_[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
